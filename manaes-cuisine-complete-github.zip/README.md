# MaNae's Cuisine - Meal Ordering System

A complete meal ordering website with shopping cart functionality and PayPal integration.

## 🍽️ Features

- **Interactive Meal Carousel**: Browse through 24 different meal options
- **Shopping Cart**: Real-time cart updates with quantity controls
- **Responsive Design**: Works perfectly on desktop, tablet, and mobile
- **PayPal Integration**: Secure payment processing
- **Order Management**: Complete checkout and confirmation flow
- **Professional Design**: Brand-consistent maroon and black color scheme

## 📁 File Structure

```
manaes-cuisine-ordering/
├── index.html              # Main ordering page with carousel
├── checkout.html           # Checkout page with customer form
├── confirmation.html       # Order confirmation page
├── script.js              # JavaScript functionality
├── images/                # All meal images and logo
│   ├── manaes_cuisine_logo.png
│   ├── meal_1.jpg
│   ├── meal_2.jpg
│   └── ... (meal_3.jpg through meal_24.jpg)
└── README.md              # This file
```

## 🚀 Deployment Options

### Option 1: GitHub Pages (Free)
1. Create a new GitHub repository
2. Upload all files to the repository
3. Go to Settings → Pages
4. Select "Deploy from a branch" → "main"
5. Your site will be available at `https://yourusername.github.io/repository-name`

### Option 2: Netlify (Free)
1. Go to [netlify.com](https://netlify.com)
2. Drag and drop the entire project folder
3. Get instant deployment with a custom URL

### Option 3: Vercel (Free)
1. Go to [vercel.com](https://vercel.com)
2. Import your GitHub repository or upload files
3. Automatic deployment with custom domain options

## ⚙️ Setup Instructions

### 1. PayPal Integration
To enable payments, you need to set up PayPal:

1. Create a PayPal Developer account at [developer.paypal.com](https://developer.paypal.com)
2. Create a new REST API app
3. Copy your Client ID
4. In `checkout.html`, replace `YOUR_PAYPAL_CLIENT_ID` with your actual Client ID
5. Uncomment the `initializePayPal()` function call

### 2. Meal Management
To update meals, edit the `meals` array in `script.js`:

```javascript
const meals = [
    { id: 1, name: "Meal Name", price: 15.99, image: "images/meal_1.jpg" },
    // Add or modify meals here
];
```

### 3. Image Updates
- Replace images in the `images/` folder
- Keep the same naming convention: `meal_1.jpg`, `meal_2.jpg`, etc.
- Logo: `manaes_cuisine_logo.png`

## 🎨 Customization

### Colors
The website uses these brand colors:
- **Primary Maroon**: `#B91C3C`
- **Secondary Black**: `#000000`
- **Accent Orange**: `#F97316`

### Layout
- **Desktop**: Three-panel layout (Info | Carousel | Cart)
- **Mobile**: Stacked vertical layout
- **Responsive**: Automatically adapts to screen size

## 📱 Mobile Features

- Touch-friendly carousel navigation
- Optimized button sizes
- Readable text on all screen sizes
- Proper form validation
- Mobile-optimized checkout flow

## 🔧 Technical Details

- **Pure HTML/CSS/JavaScript**: No frameworks required
- **Local Storage**: Cart persistence between pages
- **PayPal SDK**: Secure payment processing
- **Responsive Design**: CSS Grid and Flexbox
- **Cross-browser Compatible**: Works on all modern browsers

## 📞 Support

For customization or technical support, refer to the code comments or modify the files as needed. The system is designed to be easily maintainable and expandable.

## 🔒 Security Notes

- PayPal handles all payment processing securely
- No sensitive data is stored locally
- Customer information is only transmitted to PayPal
- All transactions are encrypted and secure

---

**MaNae's Cuisine** - Delicious meals delivered fresh to your door! 🍽️

