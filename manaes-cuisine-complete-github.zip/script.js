const meals = [
    { id: 1, name: "Grilled Herb Chicken With Seasonal Veggies", price: 15.99, image: "images/meal_1.jpg" },
    { id: 2, name: "Blackened Salmon And Shrimp With Sautéed Green Beans And Alfredo Sauce", price: 20.99, image: "images/meal_2.jpg" },
    { id: 3, name: "Shrimp With Sautéed Broccoli And Asparagus", price: 18.99, image: "images/meal_3.jpg" },
    { id: 4, name: "Southwest Chicken Taco Bowl", price: 12.99, image: "images/meal_4.jpg" },
    { id: 5, name: "Blackened Shrimp Vegetable Medley And Asparagus", price: 17.99, image: "images/meal_5.jpg" },
    { id: 6, name: "Chicken Grilled Chicken Sausage Bell Peppers And Onion Asparagus And Twice-Baked Mashed Potatoes", price: 17.99, image: "images/meal_6.jpg" },
    { id: 7, name: "Catfish Over Seasoned Rice With Bell Peppers And Onions", price: 20.99, image: "images/meal_7.jpg" },
    { id: 8, name: "Manae's Chicken & Shrimp Fried Rice", price: 15.99, image: "images/meal_8.jpg" },
    { id: 9, name: "Pesto Chicken Bake", price: 15.99, image: "images/meal_9.jpg" },
    { id: 10, name: "Cajun Chicken And Sausage Pasta", price: 18.99, image: "images/meal_10.jpg" },
    { id: 11, name: "Italian Chicken Salad", price: 16.99, image: "images/meal_11.jpg" },
    { id: 12, name: "Manae's Homemade Chicken Salad", price: 12.99, image: "images/meal_12.jpg" },
    { id: 13, name: "Manae's Salmon And Shrimp House Salad", price: 18.99, image: "images/meal_13.jpg" },
    { id: 14, name: "Chicken Taco Salad", price: 15.99, image: "images/meal_14.jpg" },
    { id: 15, name: "Manae's High Protein Chicken Salad", price: 15.99, image: "images/meal_15.jpg" },
    { id: 16, name: "Manae's Garlic Butter Shrimp And Rice Bowl With Bell Peppers And Onions", price: 16.99, image: "images/meal_16.jpg" },
    { id: 17, name: "Manae's Seasonal Fruit Bowl Small", price: 10.00, image: "images/meal_17.jpg" },
    { id: 18, name: "Large Fruit Bowl", price: 15.99, image: "images/meal_18.jpg" },
    { id: 19, name: "Blackened Salmon And Shrimp Sautéed Baked Mashed Potatoes", price: 20.99, image: "images/meal_19.jpg" },
    { id: 20, name: "Manae's Grilled Chicken Skewer With Sautéed Broccoli", price: 13.99, image: "images/meal_20.jpg" },
    { id: 21, name: "Manae's Stuffed Bell Pepper", price: 11.25, image: "images/meal_21.jpg" },
    { id: 22, name: "Manae's Vegan Stuffed Bell Pepper", price: 15.99, image: "images/meal_22.jpg" },
    { id: 23, name: "Hamburger Salad", price: 12.75, image: "images/meal_23.jpg" },
    { id: 24, name: "Manae's Salmon Loaded Salad", price: 18.99, image: "images/meal_24.jpg" }
];

let currentMealIndex = 0;
let cart = JSON.parse(localStorage.getItem('manaes_cart')) || {};

const mealCarousel = document.getElementById('mealCarousel');
const prevMealBtn = document.getElementById('prevMeal');
const nextMealBtn = document.getElementById('nextMeal');
const cartItemsContainer = document.getElementById('cartItems');
const cartTotalSpan = document.getElementById('cartTotal');
const checkoutButton = document.getElementById('checkoutButton');

function renderMeals() {
    mealCarousel.innerHTML = '';
    meals.forEach((meal, index) => {
        const mealSlide = document.createElement('div');
        mealSlide.classList.add('meal-slide');
        mealSlide.innerHTML = `
            <img src="${meal.image}" alt="${meal.name}">
            <h2>${meal.name}</h2>
            <p>$${meal.price.toFixed(2)}</p>
            <div class="quantity-control">
                <button data-id="${meal.id}" data-action="decrement">-</button>
                <input type="number" value="${cart[meal.id] ? cart[meal.id].quantity : 0}" min="0" data-id="${meal.id}" class="quantity-input">
                <button data-id="${meal.id}" data-action="increment">+</button>
            </div>
            <button class="add-to-cart-button" data-id="${meal.id}">Add to Cart</button>
        `;
        mealCarousel.appendChild(mealSlide);
    });
    updateCarouselPosition();
    renderCart();
}

function updateCarouselPosition() {
    const offset = -currentMealIndex * 100;
    mealCarousel.style.transform = `translateX(${offset}%)`;
}

function renderCart() {
    cartItemsContainer.innerHTML = '';
    let total = 0;
    for (const mealId in cart) {
        const item = cart[mealId];
        const itemTotal = item.price * item.quantity;
        total += itemTotal;
        const cartItemDiv = document.createElement('div');
        cartItemDiv.classList.add('cart-item');
        cartItemDiv.innerHTML = `
            <span>${item.name} x ${item.quantity}</span>
            <span>$${itemTotal.toFixed(2)}</span>
        `;
        cartItemsContainer.appendChild(cartItemDiv);
    }
    cartTotalSpan.textContent = `$${total.toFixed(2)}`;
    localStorage.setItem('manaes_cart', JSON.stringify(cart));
}

mealCarousel.addEventListener('click', (e) => {
    if (e.target.classList.contains('add-to-cart-button')) {
        const mealId = parseInt(e.target.dataset.id);
        const quantityInput = e.target.previousElementSibling.querySelector('.quantity-input');
        const quantity = parseInt(quantityInput.value);
        const meal = meals.find(m => m.id === mealId);

        if (quantity > 0) {
            cart[mealId] = { ...meal, quantity: (cart[mealId] ? cart[mealId].quantity : 0) + quantity };
        } else if (cart[mealId]) {
            delete cart[mealId];
        }
        renderCart();
        quantityInput.value = 0;
    }

    if (e.target.dataset.action) {
        const mealId = parseInt(e.target.dataset.id);
        const action = e.target.dataset.action;
        const quantityInput = e.target.parentNode.querySelector('.quantity-input');
        let currentQuantity = parseInt(quantityInput.value);

        if (action === 'increment') {
            currentQuantity++;
        } else if (action === 'decrement' && currentQuantity > 0) {
            currentQuantity--;
        }
        quantityInput.value = currentQuantity;
    }
});

mealCarousel.addEventListener('change', (e) => {
    if (e.target.classList.contains('quantity-input')) {
        const mealId = parseInt(e.target.dataset.id);
        const quantity = parseInt(e.target.value);
        const meal = meals.find(m => m.id === mealId);

        if (quantity > 0) {
            cart[mealId] = { ...meal, quantity: quantity };
        } else if (cart[mealId]) {
            delete cart[mealId];
        }
        renderCart();
    }
});

prevMealBtn.addEventListener('click', () => {
    currentMealIndex = (currentMealIndex > 0) ? currentMealIndex - 1 : meals.length - 1;
    updateCarouselPosition();
});

nextMealBtn.addEventListener('click', () => {
    currentMealIndex = (currentMealIndex < meals.length - 1) ? currentMealIndex + 1 : 0;
    updateCarouselPosition();
});

checkoutButton.addEventListener('click', () => {
    if (Object.keys(cart).length === 0) {
        alert('Your cart is empty. Please add some meals before checking out.');
        return;
    }
    const orderData = { items: Object.values(cart) };
    localStorage.setItem('manaes_order', JSON.stringify(orderData));
    window.location.href = 'checkout.html';
});

document.addEventListener('DOMContentLoaded', renderMeals);

